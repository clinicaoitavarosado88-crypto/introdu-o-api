const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const express = require('express');
const axios = require('axios');

const app = express();
app.use(express.json());

// Configuração
const CONFIG = {
  DO_AGENT_URL: 'https://luvswa5jnjcjhczbiiafhart.agents.do-ai.run',
  DO_API_KEY: 'y1FQFR3t_S5i_NNV_nYDoeU_me9uA3l2',
  API_BASE: 'http://sistema.clinicaoitavarosado.com.br/oitava/agenda'
};

console.log('🚀 Iniciando Bot WhatsApp - Clínica Oitava Rosado');
console.log('════════════════════════════════════════════════');
console.log('');

// Cliente WhatsApp
const client = new Client({
  authStrategy: new LocalAuth(),
  puppeteer: {
    headless: false, // MODO VISUAL - mostra navegador
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox'
    ]
  }
});

// QR Code
client.on('qr', (qr) => {
  console.log('');
  console.log('📱 QR CODE GERADO!');
  console.log('════════════════════════════════════════════════');
  console.log('');
  qrcode.generate(qr, { small: true });
  console.log('');
  console.log('════════════════════════════════════════════════');
  console.log('✅ Escaneie o QR Code acima com seu WhatsApp!');
  console.log('');
});

// Autenticando
client.on('authenticated', () => {
  console.log('✅ Autenticado com sucesso!');
});

// Carregando
client.on('loading_screen', (percent, message) => {
  console.log(`⏳ Carregando... ${percent}%`);
});

// Pronto
client.on('ready', () => {
  console.log('');
  console.log('🎉 ════════════════════════════════════════════════');
  console.log('   WHATSAPP CONECTADO COM SUCESSO!');
  console.log('════════════════════════════════════════════════════');
  console.log('');
  console.log('📱 Bot está pronto para receber mensagens!');
  console.log('');
  console.log('Para testar, envie uma mensagem para o número conectado.');
  console.log('');
});

// Mensagens recebidas
client.on('message', async (message) => {
  try {
    const from = message.from;
    const text = message.body;

    // Ignorar mensagens de grupos
    if (from.endsWith('@g.us')) {
      return;
    }

    console.log('');
    console.log('💬 ─────────────────────────────────────────────');
    console.log(`📱 De: ${from}`);
    console.log(`📝 Mensagem: ${text}`);
    console.log('─────────────────────────────────────────────');

    // Consultar agente Digital Ocean
    try {
      console.log('🤖 Consultando agente...');

      const response = await axios.post(
        CONFIG.DO_AGENT_URL,
        {
          query: text,
          context: []
        },
        {
          headers: {
            'Authorization': `Bearer ${CONFIG.DO_API_KEY}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000
        }
      );

      const resposta = response.data.response || response.data.answer || 'Desculpe, não consegui processar sua mensagem.';

      console.log('✅ Resposta do agente gerada!');
      console.log(`📤 Enviando: ${resposta.substring(0, 100)}...`);

      await message.reply(resposta);

      console.log('✅ Resposta enviada com sucesso!');
      console.log('');

    } catch (error) {
      console.log('❌ Erro ao consultar agente:', error.message);
      console.log('⚠️  Enviando resposta padrão...');

      const respostaPadrao = `Olá! 👋

Bem-vindo à *Clínica Oitava Rosado*!

Sou o assistente virtual e posso ajudar você com:
📅 Agendar consultas
📋 Ver horários disponíveis
💰 Consultar preços
❓ Tirar dúvidas

Como posso ajudar?`;

      await message.reply(respostaPadrao);
      console.log('✅ Resposta padrão enviada!');
      console.log('');
    }

  } catch (error) {
    console.log('❌ Erro ao processar mensagem:', error.message);
  }
});

// Desconectado
client.on('disconnected', (reason) => {
  console.log('');
  console.log('❌ ════════════════════════════════════════════════');
  console.log('   WhatsApp Desconectado');
  console.log('════════════════════════════════════════════════════');
  console.log('Motivo:', reason);
  console.log('');
});

// Iniciar cliente
console.log('⏳ Inicializando cliente WhatsApp...');
console.log('');
client.initialize();

// API de status (opcional)
app.get('/status', (req, res) => {
  res.json({
    status: 'running',
    whatsapp_connected: client.info ? true : false,
    timestamp: new Date().toISOString()
  });
});

app.listen(3000, () => {
  console.log('🌐 API local rodando em http://localhost:3000/status');
  console.log('');
});
